<?php

/**
 * Plugin Name: WP Personal Reviews
 * Description: WordPress plugin for personal reviews 
 * Version: 1.0.0
 * Author: ILLIA PIHOVYCH
 * Text Domain: react-personal-reviews
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Перевірка на дублювання плагіну
if (!function_exists('is_plugin_active')) {
    include_once(ABSPATH . 'wp-admin/includes/plugin.php');
}

if (is_plugin_active('wp-personal-reviews/personal-reviews.php')) {
    deactivate_plugins(plugin_basename(__FILE__));
    return;
}

// Define plugin constants
define('RPR_VERSION', '1.0.0');
define('RPR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('RPR_PLUGIN_URL', plugin_dir_url(__FILE__));

// Require core files
require_once RPR_PLUGIN_DIR . 'includes/class-database.php';
require_once RPR_PLUGIN_DIR . 'includes/class-admin.php';
require_once RPR_PLUGIN_DIR . 'includes/class-frontend.php';

class React_Personal_Reviews
{
    private static $instance = null;
    private $admin;
    private $frontend;

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        // Initialize components
        $this->admin = new Personal_Reviews_Admin();
        $this->frontend = new Personal_Reviews_Frontend();

        // Register activation/deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));

        // Add actions
        add_action('init', array($this, 'init'));
        add_action('init', array($this, 'register_all_shortcodes'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    public function register_all_shortcodes()
    {
        $saved_shortcodes = get_option('react_reviews_shortcodes', array());

        foreach ($saved_shortcodes as $shortcode) {
            add_shortcode($shortcode, array($this, 'render_reviews'));
        }
    }

    public function activate()
    {
        // Create database tables
        Personal_Reviews_Database::create_tables();

        // Set plugin version
        add_option('rpr_version', RPR_VERSION);
    }

    public function deactivate()
    {
        // Cleanup if needed
    }

    public function init()
    {
        // Register post type
        register_post_type('react_review', array(
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => false,
            'supports' => array('title', 'editor'),
            'capabilities' => array(
                'create_posts' => 'manage_options',
                'edit_post' => 'manage_options',
                'delete_post' => 'manage_options',
            ),
            'labels' => array(
                'name' => __('Reviews', 'react-personal-reviews'),
                'singular_name' => __('Review', 'react-personal-reviews')
            )
        ));

        // Register default shortcode and save to options
        $shortcodes = get_option('react_reviews_shortcodes', array());
        if (!in_array('react_reviews', $shortcodes)) {
            array_unshift($shortcodes, 'react_reviews');
            update_option('react_reviews_shortcodes', $shortcodes);
        }
        add_shortcode('react_reviews', array($this, 'render_reviews'));
    }
    public function enqueue_scripts()
    {
        global $post;
        if (!is_a($post, 'WP_Post')) {
            return;
        }

        // Get registered shortcodes
        $saved_shortcodes = get_option('react_reviews_shortcodes', array('react_reviews'));

        // Check for any of our shortcodes
        $has_reviews_shortcode = true;
        foreach ($saved_shortcodes as $shortcode) {
            if (has_shortcode($post->post_content, $shortcode)) {
                $has_reviews_shortcode = true;
                error_log("Found shortcode: " . $shortcode);
                break;
            }
        }

        if ($has_reviews_shortcode) {
            // Slick Carousel files
            wp_enqueue_style('slick', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css');
            wp_enqueue_style('slick-theme', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css');
            wp_enqueue_script('slick', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js', array('jquery'));

            wp_enqueue_style(
                'react-reviews-style',
                RPR_PLUGIN_URL . 'assets/css/personal-reviews.css',
                array(),
                RPR_VERSION
            );

            wp_enqueue_script('react');
            wp_enqueue_script('react-dom');

            wp_enqueue_script(
                'react-reviews-script',
                RPR_PLUGIN_URL . 'assets/js/personal-reviews.js',
                array('react', 'react-dom'),
                RPR_VERSION,
                true
            );

            wp_localize_script('react-reviews-script', 'reactReviewsData', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('react_reviews_nonce'),
                'is_admin' => current_user_can('manage_options'),
                'active_shortcodes' => $saved_shortcodes // Added for debug
            ));
        }
    }

    public function render_reviews($atts = array(), $content = null, $tag = '')
    {
        $shortcode = !empty($tag) ? $tag : 'react_reviews';

        return '<div id="react-personal-reviews-app" class="react-personal-reviews" data-shortcode="' . esc_attr($shortcode) . '"></div>';
    }
}

// Initialize plugin
function react_personal_reviews()
{
    return React_Personal_Reviews::get_instance();
}

// Start the plugin
react_personal_reviews();
