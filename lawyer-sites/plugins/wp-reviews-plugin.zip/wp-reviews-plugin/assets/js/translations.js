export const translations = {
    en: {
        error: 'Error',
        reviews: 'Reviews',
        leaveReview: 'Leave a review',
        yourName: 'Your name',
        yourReview: 'Your review',
        nextSlide: 'Next slide',
        prevSlide: 'Previous slide',
        loading: 'Loading...',
        sending: 'Sending...',
        socialLink: 'Social media link (optional)',
        socialMedia: "Social media"
    },
    pl: {
        error: 'Błąd',
        reviews: 'Opinie',
        leaveReview: 'Zostaw opinię',
        yourName: 'Twoje imię',
        yourReview: 'Twoja opinia',
        nextSlide: 'Następny slajd',
        prevSlide: 'Poprzedni slajd',
        loading: 'Ładowanie...',
        sending: 'Wysyłanie...',
        socialLink: 'Link do mediów społecznościowych (nieobowiązkowy)',
        socialMedia: "Media społecznościowe"
    },
    uk: {
        error: 'Помилка',
        reviews: 'Відгуки',
        leaveReview: 'Залишити відгук',
        yourName: "Ваше ім'я",
        yourReview: 'Ваш відгук',
        nextSlide: 'Наступний слайд',
        prevSlide: 'Попередній слайд',
        loading: 'Завантаження...',
        sending: 'Відправка...',
        socialLink: 'Посилання на соціальні мережі (не обов\'язково)',
        socialMedia: "Соціальна мережа"
    },
    ru: {
        error: 'Ошибка',
        reviews: 'Отзывы',
        leaveReview: 'Оставить отзыв',
        yourName: 'Ваше имя',
        yourReview: 'Ваш отзыв',
        nextSlide: 'Следующий слайд',
        prevSlide: 'Предыдущий слайд',
        loading: 'Загрузка...',
        sending: 'Отправка...',
        socialLink: 'Ссылка на социальные сети (не обязательно)',
        socialMedia: "Социальная сеть"

    }
};