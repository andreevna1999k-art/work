//@ts-check

const translations = {
    en: {
        error: 'Error',
        reviews: 'Reviews',
        leaveReview: 'Leave a review',
        yourName: 'Your name',
        yourReview: 'Your review',
        nextSlide: 'Next slide',
        prevSlide: 'Previous slide',
        loading: 'Loading...',
        sending: 'Sending...',
        socialLink: 'Your social link (optional)',
        socialMedia: 'Contact the reviewer'
    },
    pl: {
        error: 'Błąd',
        reviews: 'Opinie',
        leaveReview: 'Zostaw opinię',
        yourName: 'Twoje imię',
        yourReview: 'Twoja opinia',
        nextSlide: 'Następny slajd',
        prevSlide: 'Poprzedni slajd',
        loading: 'Ładowanie...',
        sending: 'Wysyłanie...',
        socialLink: 'Twój link do mediów społecznościowych (nieobowiązkowy)',
        socialMedia: 'Skontaktuj się z autorem opinii'
    },
    uk: {
        error: 'Помилка',
        reviews: 'Відгуки',
        leaveReview: 'Залишити відгук',
        yourName: "Ваше ім'я",
        yourReview: 'Ваш відгук',
        nextSlide: 'Наступний слайд',
        prevSlide: 'Попередній слайд',
        loading: 'Завантаження...',
        sending: 'Відправка...',
        socialLink: 'Ваше посилання на соціальні мережі (не обов\'язково)',
        socialMedia: 'Зв\'язатися з автором відгуку'
    },
    ru: {
        error: 'Ошибка',
        reviews: 'Отзывы',
        leaveReview: 'Оставить отзыв',
        yourName: 'Ваше имя',
        yourReview: 'Ваш отзыв',
        nextSlide: 'Следующий слайд',
        prevSlide: 'Предыдущий слайд',
        loading: 'Загрузка...',
        sending: 'Отправка...',
        socialLink: 'Ваша ссылка на социальные сети (не обязательно)',
        socialMedia: 'Связаться с автором отзыва'
    }
};

const getPageLanguage = () => {
    const hreflangTag = document.querySelector('link[hreflang]');
    const langFromTag = hreflangTag ? hreflangTag.getAttribute('hreflang').split('-')[0] : null;
    const langFromHtml = document.documentElement.lang ? document.documentElement.lang.split('-')[0] : null;

    if (langFromTag && translations[langFromTag]) {
        return langFromTag;
    } else if (langFromHtml && translations[langFromHtml]) {
        return langFromHtml;
    } else {
        return 'ru';
    }
};

const currentLang = getPageLanguage();
const t = translations[currentLang]

// console.log('translations[currentLang]', translations[currentLang])


function PersonalReviews() {
    const [reviews, setReviews] = React.useState([])
    const [currentSlide, setCurrentSlide] = React.useState(0)
    const [slidesToShow, setSlidesToShow] = React.useState(3)
    const [formData, setFormData] = React.useState({
        reviewer_name: '',
        review_rating: 5,
        review_text: '',
        social_link: '',
    })
    const [message, setMessage] = React.useState('')
    const [loading, setLoading] = React.useState(false)
    const [displaySettings, setDisplaySettings] = React.useState({
        displayMode: 'carousel', // or 'list'
    })


    // Handle window resize
    React.useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth < 600) {
                setSlidesToShow(1)
            } else if (window.innerWidth < 1024) {
                setSlidesToShow(2)
            } else {
                setSlidesToShow(3)
            }
        }

        window.addEventListener('resize', handleResize)
        handleResize()

        // Auto-advance slides every 5 seconds
        const timer = setInterval(() => {
            nextSlide()
        }, 5000)

        return () => {
            window.removeEventListener('resize', handleResize)
            clearInterval(timer)
        }
    }, [])

    React.useEffect(() => {
        fetchReviews();
    }, []);

    // Navigation functions
    const nextSlide = () => {
        setCurrentSlide((current) => {
            const lastIndex = Math.max(0, reviews.length - slidesToShow)
            return current >= lastIndex ? 0 : current + 1
        })
    }

    const prevSlide = () => {
        setCurrentSlide((current) => {
            const lastIndex = Math.max(0, reviews.length - slidesToShow)
            return current <= 0 ? lastIndex : current - 1
        })
    }

    const goToSlide = (index) => {
        setCurrentSlide(Math.min(index, reviews.length - slidesToShow))
    }

    // Carousel styles
    const carouselStyles = {
        container: {
            position: 'relative',
            overflow: 'hidden',
            padding: '30px 40px',
            marginBottom: '50px',
        },
        wrapper: {
            display: 'flex',
            transition: 'transform 0.3s ease',
            transform: `translateX(-${currentSlide * (100 / slidesToShow)}%)`,
        },
        slide: {
            flex: `0 0 ${100 / slidesToShow}%`,
            padding: '0 10px',
            boxSizing: 'border-box',
        },
        navButton: {
            position: 'absolute',
            top: '50%',
            transform: 'translateY(-50%)',
            width: '40px',
            height: '40px',
            // background: '#007bff' 
            color: 'white',
            border: 'none',
            borderRadius: '50%',
            cursor: 'pointer',
            zIndex: 1,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
        },
        dots: {
            display: 'flex',
            justifyContent: 'center',
            position: 'absolute',
            bottom: '-70px',
            width: 'calc(100% - 80px)',
            height: '80px',
            padding: '0',
            margin: '0',
            listStyle: 'none',
            boxSizing: 'border-box',
        },
        dot: {
            width: '10px',
            height: '10px',
            margin: '0 5px',
            borderRadius: '50%',
            background: '#595959',
            cursor: 'pointer',
            border: 'none',
            padding: '0',
            boxSizing: 'border-box',
        },
        activeDot: {
            background: '#fff',
            border: '1px solid #333',
        },
    }

    const filterReviews = (reviews, userCookie) => {
        if (!Array.isArray(reviews)) return [];
        return reviews.filter(review =>
            review.status === 'approved' || review.user_cookie === userCookie
        );
    };

    const getGroupReviews = (reviews) => {
        // Get shortcode from container
        const container = document.querySelector('.react-personal-reviews');
        const currentShortcode = container?.dataset.shortcode || 'react_reviews';

        return reviews.filter(review => review.group_id === currentShortcode);
    };

    const fetchReviews = async () => {
        // console.log('fetchReviews')
        setLoading(true)
        const userCookie = getCookie('review_user_id');
        const formData = new FormData()
        formData.append('action', 'get_reviews')
        formData.append('nonce', reactReviewsData.nonce)

        try {
            const response = await fetch(reactReviewsData.ajax_url, {
                method: 'POST',
                body: formData,
            })
            const result = await response.json()
            if (result.success) {
                // console.log('fetchReviews result.data', result.data)
                const groupReviews = getGroupReviews(result.data.reviews);
                // console.log('groupReviews', groupReviews)
                const userReviews = filterReviews(groupReviews, userCookie);
                // console.log('filteredReviews', userReviews)
                const displayLimit = result.data.settings?.display_limit || 10;
                // console.log('displayLimit', displayLimit)
                let limitedReviews = userReviews.slice(0, displayLimit);
                // console.log('limitedReviews', limitedReviews)

                setReviews(limitedReviews);

                result.data.settings && setDisplaySettings(result.data.settings);
            }
        } catch (error) {
            console.error('Error fetching reviews:', error)
        } finally {
            setLoading(false)
        }
    }

    const generateUserId = () => {
        return 'user_' + Math.random().toString(36).substr(2, 9)
    }

    const setCookie = (name, value, days) => {
        let expires = ''
        if (days) {
            const date = new Date()
            date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000)
            expires = '; expires=' + date.toUTCString()
        }
        document.cookie = name + '=' + (value || '') + expires + '; path=/'
    }

    const getCookie = (name) => {
        const nameEQ = name + '='
        const ca = document.cookie.split(';')
        for (let i = 0; i < ca.length; i++) {
            let c = ca[i]
            while (c.charAt(0) === ' ') c = c.substring(1, c.length)
            if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length)
        }
        return null
    }

    const handleSubmit = async (e) => {
        console.log('handleSubmit')
        e.preventDefault()
        setLoading(true)
        setMessage('')

        console.log('Initial formData:', {
            reviewer_name: formData.reviewer_name,
            review_rating: formData.review_rating,
            review_text: formData.review_text,
            social_link: formData.social_link,
        })

        // Get shortcode from container
        const container = document.querySelector('.react-personal-reviews');
        let shortcode = container?.dataset.shortcode || 'react_reviews';
        console.log('shortcode', shortcode)

        // Get existing cookie or generate new one
        let userCookie = getCookie('review_user_id')
        if (!userCookie) {
            userCookie = generateUserId()
            console.log('generrated userCookie', userCookie)
            setCookie('review_user_id', userCookie, 365) // Save for 1 year
        } else {
            console.log('userCookie exist', userCookie)
        }

        const submitData = new FormData()
        submitData.append('action', 'submit_review')
        submitData.append('nonce', reactReviewsData.nonce)
        submitData.append('user_cookie', userCookie)
        submitData.append('group_id', shortcode)

        Object.keys(formData).forEach((key) => {
            // console.log('Adding formData[key]:', key, formData[key])
            submitData.append(key, formData[key])
        })

        console.log('submitData', submitData)
        for (let pair of submitData.entries()) {
            console.log('submitData pair', pair[0], pair[1])
        }

        try {
            const response = await fetch(reactReviewsData.ajax_url, {
                method: 'POST',
                body: submitData,
            })
            const result = await response.json()

            if (result.data.user_cookie) {
                // Output cookie to console
                console.log('User Cookie:', result.data.user_cookie)
            } else if (result.data) {
                // console.log('result.data', result.data)
                // console.log('result', result)
            }

            if (result.success) {
                setMessage(result.data.message)

                //очищає форму після успішного відправлення відгуку
                setFormData({
                    reviewer_name: '',
                    review_rating: 5,
                    review_text: '',
                    social_link: '',
                })
                fetchReviews()
            } else {
                setMessage(result.error || 'Помилка при відправці відгуку')
            }
        } catch (error) {
            console.error('Error submitting review:', error)
            setMessage('Помилка при відправці. Спробуйте ще раз.')
        } finally {
            console.log('finally')
            setLoading(false)
        }
    }

    const handleInputChange = (e) => {
        const { name, value } = e.target
        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }))
    }

    const renderStars = (rating) => {
        return '★'.repeat(rating) + '☆'.repeat(5 - rating)
    }

    const shouldShowNavigation = (reviews) => {
        return Array.isArray(reviews) && reviews.length > 0;
    };

    return React.createElement(
        'div',
        { className: 'personal-reviews-container' },

        // Form
        React.createElement(
            'form',
            {
                className: 'review-form',
                onSubmit: handleSubmit,
            },
            React.createElement('h3', null, t.leaveReview),
            React.createElement(
                'div',
                { className: 'form-group' },
                React.createElement('input', {
                    type: 'text',
                    name: 'reviewer_name',
                    value: formData.reviewer_name,
                    onChange: handleInputChange,
                    placeholder: t.yourName,
                    required: true,
                })
            ),
            React.createElement(
                'div',
                { className: 'form-group' },
                React.createElement(
                    'div',
                    {
                        style: { position: 'relative', display: 'inline-block', width: '200px' },
                    },
                    [
                        React.createElement(
                            'select',
                            {
                                name: 'review_rating',
                                value: formData.review_rating,
                                onChange: handleInputChange,
                                style: {
                                    appearance: 'none',
                                    WebkitAppearance: 'none',
                                    MozAppearance: 'none',
                                    border: '1px solid #ccc',
                                    padding: '10px',
                                    width: '100%',
                                    borderRadius: '4px',
                                    backgroundColor: 'white',
                                    backgroundImage: 'none'
                                },
                            },
                            [
                                React.createElement('option', { value: 5 }, '5 ★★★★★'),
                                React.createElement('option', { value: 4 }, '4 ★★★★☆'),
                                React.createElement('option', { value: 3 }, '3 ★★★☆☆'),
                                React.createElement('option', { value: 2 }, '2 ★★☆☆☆'),
                                React.createElement('option', { value: 1 }, '1 ★☆☆☆☆'),
                            ]
                        ),
                        React.createElement(
                            'svg',
                            {
                                xmlns: 'http://www.w3.org/2000/svg',
                                viewBox: '0 0 24 24',
                                fill: 'none',
                                stroke: 'currentColor',
                                strokeWidth: '2',
                                strokeLinecap: 'round',
                                strokeLinejoin: 'round',
                                style: {
                                    position: 'absolute',
                                    top: '50%',
                                    right: '10px',
                                    transform: 'translateY(-50%)',
                                    pointerEvents: 'none',
                                    width: '20px',
                                    height: '20px',
                                },
                            },
                            React.createElement('path', { d: 'M6 9l6 6 6-6' })
                        ),
                    ]
                )
            ),
            React.createElement(
                'div',
                { className: 'form-group' },
                React.createElement('textarea', {
                    name: 'review_text',
                    value: formData.review_text,
                    onChange: handleInputChange,
                    placeholder: t.yourReview,
                    required: true,
                })
            ),
            React.createElement(
                'div',
                { className: 'form-group' },
                React.createElement('input', {
                    type: 'url',
                    name: 'social_link',
                    value: formData.social_link,
                    onChange: handleInputChange,
                    placeholder: t.socialLink,
                })
            ),
            React.createElement(
                'button',
                {
                    className: 'reviews-submit-button',
                    type: 'submit',
                    disabled: loading,
                },
                loading ? t.sending : t.leaveReview
            ),
            message &&
            React.createElement(
                'div',
                {
                    className: `message ${message.includes(t.error) ? 'error' : 'success'}`,
                },
                message
            )
        ),

        // Reviews Section
        shouldShowNavigation(reviews) && (
            displaySettings.displayMode === 'list' ? (
                // List View
                React.createElement(
                    'div',
                    { className: 'reviews-list' },
                    reviews.map((review) =>
                        React.createElement(
                            'div',
                            {
                                key: review.id,
                                className: 'review-card list-view'
                            },
                            React.createElement('h3', null, review.name),
                            React.createElement(
                                'div',
                                { className: 'rating' },
                                renderStars(review.rating)
                            ),
                            React.createElement(
                                'p',
                                { className: 'review-text' },
                                review.review_text
                            ),
                            review.social_link &&
                            React.createElement(
                                'a',
                                {
                                    href: review.social_link,
                                    target: '_blank',
                                    rel: 'noopener noreferrer',
                                    className: 'social-link',
                                },
                                t.socialMedia
                            ),
                            React.createElement(
                                'div',
                                { className: 'review-date' },
                                review.date_formatted
                            )
                        )
                    )
                )
            ) : (
                // Carousel View
                React.createElement(
                    'div',
                    { className: 'carousel-container', style: carouselStyles.container },
                    // Prev Button
                    React.createElement(
                        'button',
                        {
                            className: 'carousel-button-left carousel-button',
                            onClick: prevSlide,
                            style: { ...carouselStyles.navButton, left: 0 },
                        },
                        React.createElement(
                            'svg',
                            {
                                xmlns: 'http://www.w3.org/2000/svg',
                                viewBox: '0 0 24 24',
                                fill: 'none',
                                stroke: 'currentColor',
                                strokeWidth: '2',
                                strokeLinecap: 'round',
                                strokeLinejoin: 'round',
                                style: { width: '20px', height: '20px' },
                            },
                            React.createElement('path', {
                                d: 'M15 18l-6-6 6-6',
                            })
                        )
                    ),

                    // Slides Container
                    React.createElement(
                        'div',
                        { className: 'carousel-slides', style: carouselStyles.wrapper },
                        reviews.map((review) =>
                            React.createElement(
                                'div',
                                {
                                    key: review.id,
                                    style: carouselStyles.slide,
                                },
                                React.createElement(
                                    'div',
                                    { className: 'review-card' },
                                    React.createElement('h3', null, review.name),
                                    React.createElement(
                                        'div',
                                        { className: 'rating' },
                                        renderStars(review.rating)
                                    ),
                                    React.createElement(
                                        'p',
                                        { className: 'review-text' },
                                        review.review_text
                                    ),
                                    review.social_link &&
                                    React.createElement(
                                        'a',
                                        {
                                            href: review.social_link,
                                            target: '_blank',
                                            rel: 'noopener noreferrer',
                                            className: 'social-link',
                                        },
                                        t.socialMedia
                                    ),
                                    React.createElement(
                                        'div',
                                        { className: 'review-date' },
                                        review.date_formatted
                                    )
                                )
                            )
                        )
                    ),

                    // Next Button
                    React.createElement(
                        'button',
                        {
                            className: 'carousel-button-right carousel-button',
                            onClick: nextSlide,
                            style: { ...carouselStyles.navButton, right: 0 },
                        },
                        React.createElement(
                            'svg',
                            {
                                xmlns: 'http://www.w3.org/2000/svg',
                                viewBox: '0 0 24 24',
                                fill: 'none',
                                stroke: 'currentColor',
                                strokeWidth: '2',
                                strokeLinecap: 'round',
                                strokeLinejoin: 'round',
                                style: { width: '20px', height: '20px' },
                            },
                            React.createElement('path', {
                                d: 'M9 18l6-6-6-6',
                            })
                        )
                    ),

                    // Dots Navigation
                    React.createElement(
                        'div',
                        { className: 'carousel-dots', style: carouselStyles.dots },
                        Array.from({
                            length: reviews.length
                        }).map((_, index) =>
                            React.createElement('button', {
                                className: 'carousel-dot',
                                key: index,
                                onClick: () => goToSlide(index),
                                style: {
                                    ...carouselStyles.dot,
                                    ...(currentSlide === index ? carouselStyles.activeDot : {}),
                                },
                            })
                        )
                    )
                )
            )
        )
    )
}


ReactDOM.render(
    React.createElement(PersonalReviews),
    document.getElementById('react-personal-reviews-app')
);
