<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;
$table_name = $wpdb->prefix . 'personal_reviews';

// Видалення таблиці
$wpdb->query("DROP TABLE IF EXISTS $table_name");

// Видалення опцій плагіну
delete_option('rpr_version');
delete_option('reviews_display_limit');
delete_option('react_reviews_shortcodes');
delete_option('personal_reviews_db_version');

// Очистка кешу
delete_transient('rpr_cache_reviews');

// Видалення метаданих користувачів
$wpdb->query("DELETE FROM $wpdb->usermeta WHERE meta_key LIKE 'rpr_%'");

// Видалення завантажених файлів
$upload_dir = wp_upload_dir();
$reviews_dir = $upload_dir['basedir'] . '/reviews';
if (is_dir($reviews_dir)) {
    foreach (glob($reviews_dir . '/*') as $file) {
        if (is_file($file)) unlink($file);
    }
    rmdir($reviews_dir);
}