<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="review-form-container">
    <h3><?php _e('Залишити відгук', 'react-personal-reviews'); ?></h3>
    
    <form id="review-submission-form" class="review-form">
        <?php wp_nonce_field('submit_review', 'review_nonce'); ?>
        
        <div class="form-group">
            <label for="reviewer_name">
                <?php _e('Ваше ім\'я', 'react-personal-reviews'); ?> <span class="required">*</span>
            </label>
            <input 
                type="text" 
                id="reviewer_name" 
                name="reviewer_name" 
                required 
                maxlength="100"
            >
        </div>

        <div class="form-group">
            <label for="review_rating">
                <?php _e('Рейтинг', 'react-personal-reviews'); ?> <span class="required">*</span>
            </label>
            <select id="review_rating" name="review_rating" required>
                <option value=""><?php _e('Виберіть рейтинг', 'react-personal-reviews'); ?></option>
                <?php for($i = 5; $i >= 1; $i--): ?>
                    <option value="<?php echo $i; ?>"><?php echo str_repeat('★', $i) . str_repeat('☆', 5-$i); ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="review_text">
                <?php _e('Ваш відгук', 'react-personal-reviews'); ?> <span class="required">*</span>
            </label>
            <textarea 
                id="review_text" 
                name="review_text" 
                required 
                rows="5"
                maxlength="1000"
            ></textarea>
        </div>

        <div class="form-group">
            <label for="social_link">
                <?php _e('Посилання на соціальну мережу', 'react-personal-reviews'); ?>
            </label>
            <input 
                type="url" 
                id="social_link" 
                name="social_link" 
                placeholder="https://"
            >
        </div>

        <div class="form-submit">
            <button type="submit" class="submit-review-button">
                <?php _e('Надіслати відгук', 'react-personal-reviews'); ?>
            </button>
        </div>

        <div id="review-form-messages" class="form-messages"></div>
    </form>
</div>

<script>
document.getElementById('review-submission-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    formData.append('action', 'submit_review');

    fetch(reactReviewsData.ajax_url, {
        method: 'POST',
        body: formData,
        credentials: 'same-origin'
    })
    .then(response => response.json())
    .then(data => {
        const messageDiv = document.getElementById('review-form-messages');
        messageDiv.textContent = data.success ? data.data : data.error;
        messageDiv.className = 'form-messages ' + (data.success ? 'success' : 'error');
        
        if (data.success) {
            this.reset();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('review-form-messages').textContent = 
            'Сталася помилка при відправці. Спробуйте ще раз.';
    });
});
</script>