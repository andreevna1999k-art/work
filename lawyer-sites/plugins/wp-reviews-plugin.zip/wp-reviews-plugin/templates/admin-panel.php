<?php
if (!defined('ABSPATH')) {
    exit;
}

// Check admin access
if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}
?>

<div class="wrap">
    <h1><?php _e('Управління відгуками', 'react-personal-reviews'); ?></h1>

    <div id="reviews-admin-panel">
        <div class="tablenav top">
            <div class="alignleft actions">
                <div class="alignleft actions">
                    <select id="bulk-action-selector">
                        <option value="-1"><?php _e('Групові дії', 'react-personal-reviews'); ?></option>
                        <option value="approve"><?php _e('Схвалити', 'react-personal-reviews'); ?></option>
                        <option value="delete"><?php _e('Видалити', 'react-personal-reviews'); ?></option>
                    </select>
                    <button class="button" id="doaction"><?php _e('Застосувати', 'react-personal-reviews'); ?></button>
                </div>
                <div class="alignleft actions">
                    <select id="display-mode-selector">
                        <option value="carousel"><?php _e('Карусель', 'react-personal-reviews'); ?></option>
                        <option value="list"><?php _e('Список', 'react-personal-reviews'); ?></option>
                    </select>
                    <button class="button" id="save-display-mode"><?php _e('Зберегти', 'react-personal-reviews'); ?></button>
                </div>
                <div class="alignleft actions">
                    <input
                        type="number"
                        id="display-limit"
                        min="1"
                        value="<?php echo get_option('reviews_display_limit', 10); ?>"
                        style="width: 60px;"
                        placeholder="Кількість">
                    <button class="button" id="save-display-limit">Зберегти кількість</button>
                </div>
                <div class="alignleft actions">
                    <input
                        type="text"
                        id="new-shortcode-name"
                        placeholder="<?php _e('Назва групи відгуків', 'react-personal-reviews'); ?>">
                    <button class="button" id="add-shortcode">
                        <?php _e('Додати групу', 'react-personal-reviews'); ?>
                    </button>
                </div>
            </div>
            <div class="tablenav-pages">
                <span class="displaying-num" id="reviews-count"></span>
                <span class="pagination-links" id="reviews-pagination"></span>
            </div>
        </div>

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th scope="col" class="manage-column column-cb check-column">
                        <input type="checkbox" id="cb-select-all">
                    </th>
                    <th scope="col"><?php _e('Імʼя', 'react-personal-reviews'); ?></th>
                    <th scope="col" class="narrow-column"><?php _e('Рейтинг', 'react-personal-reviews'); ?></th>
                    <th scope="col"><?php _e('Відгук', 'react-personal-reviews'); ?></th>
                    <th scope="col" class="medium-width-column"><?php _e('Соц. мережа', 'react-personal-reviews'); ?></th>
                    <th scope="col" class="medium-width-column"><?php _e('Дата', 'react-personal-reviews'); ?></th>
                    <th scope="col"><?php _e('Група', 'react-personal-reviews'); ?></th>
                    <th scope="col" class="narrow-column"><?php _e('Статус', 'react-personal-reviews'); ?></th>
                    <th scope="col" class="width-8"><?php _e('Дії', 'react-personal-reviews'); ?></th>
                </tr>
            </thead>
            <tbody id="reviews-list"></tbody>
        </table>
    </div>
</div>

<script>
    jQuery(document).ready(function($) {
        // Load current display mode setting
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'get_display_mode',
                nonce: '<?php echo wp_create_nonce("display_mode_nonce"); ?>'
            },
            success: function(response) {
                if (response.success) {
                    $('#display-mode-selector').val(response.data.mode);
                }
            }
        });


        $('#save-display-mode').click(function() {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'save_display_mode',
                    mode: $('#display-mode-selector').val(),
                    nonce: '<?php echo wp_create_nonce("display_mode_nonce"); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        alert('<?php _e("Налаштування збережено", "react-personal-reviews"); ?>');
                    }
                }
            });
        });

        $('#save-display-limit').click(function() {
            const limit = $('#display-limit').val();
            console.log("limit in save-display-limit", limit);
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'update_display_limit',
                    limit: limit,
                    nonce: '<?php echo wp_create_nonce("reviews_admin_nonce"); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        alert('Ліміт оновлено');
                    }
                }
            });
        });


        const prefix = 'react_reviews_';

        $('#new-shortcode-name').on('focus', function() {
            if (!this.value.startsWith(prefix)) {
                this.value = prefix;
            }
        }).on('input', function() {
            if (!this.value.startsWith(prefix)) {
                this.value = prefix;
            }
        });

        $('#add-shortcode').click(function() {
            console.log("add-shortcode clicked");
            const name = $('#new-shortcode-name').val();
            console.log("name in add-shortcode", name);
            if (!name) return;

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'add_review_shortcode',
                    name: name,
                    nonce: '<?php echo wp_create_nonce("reviews_admin_nonce"); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        // Add new shortcode to all group selects
                        const selects = $('[id^="group_edit_"]');
                        selects.each(function() {
                            $(this).append(`<option value="${name}">${name}</option>`);
                        });

                        $('#new-shortcode-name').val('');
                        alert('Групу додано');
                        console.log("updated shortcodes", response);
                    } else {
                        console.table('Error add-shortcode:', response);
                    }
                }
            });
        });

        window.loadReviews = function(page = 1) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'get_reviews_admin',
                    nonce: '<?php echo wp_create_nonce('reviews_admin_nonce'); ?>',
                    page: page
                },
                success: function(response) {
                    console.log("response in loadReviews", response);
                    if (response.success) {
                        console.log("Active WordPress Shortcodes:", response.data.active_shortcodes);
                        renderReviews(response.data.reviews);
                        updatePagination(response.data.total, response.data.per_page, page);
                    }
                }
            });
        }

        function updateReviewDate(reviewId, newDate) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'update_review_date',
                    review_id: reviewId,
                    date: newDate,
                    nonce: '<?php echo wp_create_nonce('reviews_admin_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        const input = document.getElementById(`date_${reviewId}`);
                        if (input._flatpickr) {
                            input._flatpickr.close();
                        }
                        alert('Дату оновлено');
                        loadReviews();
                    }
                }
            });
        }

        function updatePagination(total, perPage, currentPage) {
            const totalPages = Math.ceil(total / perPage);
            const paginationContainer = $('#reviews-pagination');
            const countDisplay = $('#reviews-count');

            // Показуємо загальну кількість
            countDisplay.text(`${total} елементів`);

            // Очищаємо контейнер пагінації
            paginationContainer.empty();

            if (totalPages <= 1) return;

            // Кнопка "Назад"
            paginationContainer.append(`
                <button class="button" 
                    ${currentPage === 1 ? 'disabled' : ''} 
                    onclick="loadReviews(${currentPage - 1})">
                    &laquo;
                </button>
            `);

            // Номери сторінок
            for (let i = 1; i <= totalPages; i++) {
                if (
                    i === 1 || // Перша сторінка
                    i === totalPages || // Остання сторінка
                    (i >= currentPage - 2 && i <= currentPage + 2) // 2 сторінки до і після поточної
                ) {
                    paginationContainer.append(`
                <button class="button ${i === currentPage ? 'current' : ''}" 
                    onclick="loadReviews(${i})">
                    ${i}
                </button>
            `);
                } else if (
                    i === currentPage - 3 ||
                    i === currentPage + 3
                ) {
                    paginationContainer.append('<span>...</span>');
                }
            }

            // Кнопка "Вперед"
            paginationContainer.append(`
                <button class="button" 
                    ${currentPage === totalPages ? 'disabled' : ''} 
                    onclick="loadReviews(${currentPage + 1})">
                    &raquo;
                </button>
            `);
        }

        function toggleLinkEdit(reviewId) {
            console.log("reviewId in toggleLinkEdit", reviewId);
            const displaySpan = document.getElementById(`link_display_${reviewId}`);
            const input = document.getElementById(`link_edit_${reviewId}`);
            const editBtn = document.querySelector(`button.edit-link[data-id="${reviewId}"]`);
            const saveBtn = document.querySelector(`button.save-link[data-id="${reviewId}"]`);

            const isEditing = input.style.display === 'block';

            displaySpan.style.display = isEditing ? 'block' : 'none';
            input.style.display = isEditing ? 'none' : 'block';
            editBtn.style.display = isEditing ? 'inline-flex' : 'none';
            saveBtn.style.display = isEditing ? 'none' : 'inline-flex';
        }

        function saveSocialLink(reviewId) {

            const input = document.getElementById(`link_edit_${reviewId}`);
            console.log("reviewId in saveSocialLink", reviewId);
            const newLink = input.value;
            console.log("newLink in saveSocialLink", newLink);

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'update_social_link',
                    review_id: reviewId,
                    social_link: newLink,
                    nonce: '<?php echo wp_create_nonce('reviews_admin_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        alert('Посилання оновлено');
                        loadReviews();
                    }
                }
            });
        }

        function toggleGroupEdit(reviewId) {
            const display = document.getElementById(`group_display_${reviewId}`);
            const select = document.getElementById(`group_edit_${reviewId}`);
            const editBtn = document.querySelector(`button.edit-group[data-id="${reviewId}"]`);
            const saveBtn = document.querySelector(`button.save-group[data-id="${reviewId}"]`);

            display.style.display = 'none';
            select.style.display = 'block';
            editBtn.style.display = 'none';
            saveBtn.style.display = 'inline-flex';
        }

        function handleGroupEditBlur(reviewId) {
            console.log("reviewId in handleGroupEditBlur", reviewId);
            const display = document.getElementById(`group_display_${reviewId}`);
            const select = document.getElementById(`group_edit_${reviewId}`);
            const editBtn = document.querySelector(`button.edit-group[data-id="${reviewId}"]`);
            const saveBtn = document.querySelector(`button.save-group[data-id="${reviewId}"]`);

            display.style.display = 'block';
            select.style.display = 'none';
            editBtn.style.display = 'inline-flex';
            saveBtn.style.display = 'none';
        }

        function saveGroup(reviewId) {
            const select = document.getElementById(`group_edit_${reviewId}`);
            const newGroup = select.value;

            console.log('Saving group:', {
                reviewId: reviewId,
                newGroup: newGroup
            });

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'update_review_group',
                    review_id: reviewId,
                    group_id: newGroup,
                    nonce: '<?php echo wp_create_nonce('reviews_admin_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        alert('Групу успішно змінено');
                        console.log('Available shortcodes:', response.data.shortcodes);
                        loadReviews();
                    } else {
                        console.error('Error:', response.data);

                    }
                },
                error: function(error) {
                    console.error('AJAX error:', {
                        status: status,
                        error: error,
                        response: xhr.responseText
                    });
                }
            });
        }

        function renderReviews(reviews) {
            console.log("reviews in renderReviews", reviews);
            const tbody = $('#reviews-list');
            tbody.empty();

            reviews.forEach(review => {
                tbody.append(`
                <tr data-id="${review.id}">
                    <td><input type="checkbox" name="review[]" value="${review.id}"></td>
                    <td class="medium-width-column">${review.name}</td>
                    <td class="narrow-column">${'★'.repeat(review.rating)}${'☆'.repeat(5-review.rating)}</td>
                    <td>${review.review_text}</td>
                    <td>
                        <div style="display: flex; align-items: center; gap: 5px;">
                            <span id="link_display_${review.id}" class="link-display">
                                ${review.social_link ? 
                                    `<a href="${review.social_link}" target="_blank">${review.social_link}</a>` : 
                                    '-'
                                }
                            </span>
                            <input 
                                type="text" 
                                id="link_edit_${review.id}" 
                                class="editable-field"
                                value="${review.social_link || ''}" 
                                style="display: none; width: 100%;"
                            >
                            <button 
                                class="button edit-link" 
                                data-id="${review.id}"
                            >
                                <span class="dashicons dashicons-edit"></span>
                            </button>
                            <button 
                                class="button save-link" 
                                data-id="${review.id}"
                                style="display: none;" 
                            >
                                <span class="dashicons dashicons-saved"></span>
                            </button>
                        </div>
                    </td>
                    <td style="width: 7%;">
                        <div style="display: flex; align-items: center;">
                            <input 
                                type="text" 
                                id="date_${review.id}"
                                value="${review.date_formatted || review.date_added}"
                                class="flatpickr-input date-input"
                                data-review-id="${review.id}"
                            >
                        </div>
                    </td>
                    <td>
                        <div style="display: flex; align-items: center; gap: 5px;">
                            <span id="group_display_${review.id}" class="group-display">
                                ${review.group_id || '-'}
                            </span>
                            <select 
                                id="group_edit_${review.id}" 
                                class="editable-field"
                                style="display: none;"
                            >
                                ${(() => {
                                    const shortcodes = <?php echo json_encode(get_option('react_reviews_shortcodes', array('1'))); ?>;
                                    return shortcodes.map(code => 
                                        `<option value="${code}" ${review.group_id === code ? 'selected' : ''}>
                                            ${code}
                                        </option>`
                                    ).join('');
                                })()}
                            </select>
                            <button 
                                class="button edit-group" 
                                data-id="${review.id}"
                             >
                                <span class="dashicons dashicons-edit"></span>
                            </button>
                            <button 
                                class="button save-group" 
                                data-id="${review.id}"
                                style="display: none;"
                            >
                                <span class="dashicons dashicons-saved"></span>
                            </button>
                        </div>
                    </td>
                    <td class="narrow-column status-td">${review.status}</td>
                    <td class="width-8">
                        ${review.status === 'pending' ? 
                            `<button class="button approve-review" data-id="${review.id}">✅</button>` : 
                            ''
                        }
                        <button class="button delete-review" data-id="${review.id}">❌</button>
                    </td>
                </tr>
                `);

                // Initialize Flatpickr for this row
                flatpickr(`#date_${review.id}`, {
                    enableTime: true,
                    dateFormat: "Y-m-d H:i:S",
                    position: "center",
                    onChange: function(selectedDates, dateStr) {
                        updateReviewDate(review.id, dateStr);
                    }
                });
            });
        }

        $(document).on('click', '.approve-review', function() {
            const reviewId = $(this).data('id');
            approveReview(reviewId);
        });

        $(document).on('click', '.delete-review', function() {
            const reviewId = $(this).data('id');
            if (confirm('Ви впевнені, що хочете видалити цей відгук?')) {
                deleteReview(reviewId);
            }
        });

        function approveReview(id) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'approve_review',
                    review_id: id,
                    nonce: '<?php echo wp_create_nonce('reviews_admin_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        loadReviews();
                    }
                }
            });
        }

        function deleteReview(id) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'delete_review',
                    review_id: id,
                    nonce: '<?php echo wp_create_nonce('reviews_admin_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        loadReviews();
                    }
                }
            });
        }

        $('#doaction').click(function() {
            const action = $('#bulk-action-selector').val();
            const selected = $('input[name="review[]"]:checked').map(function() {
                return $(this).val();
            }).get();

            if (action === '-1' || selected.length === 0) return;

            if (action === 'delete' && !confirm('Видалити вибрані відгуки?')) return;

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'bulk_' + action + '_reviews',
                    review_ids: selected,
                    nonce: '<?php echo wp_create_nonce('reviews_admin_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        loadReviews();
                    }
                }
            });
        });

        $(document).on('click', '.edit-link', function() {
            const reviewId = $(this).data('id');
            toggleLinkEdit(reviewId);
        });

        $(document).on('click', '.save-link', function() {
            const reviewId = $(this).data('id');
            saveSocialLink(reviewId);
        });

        $(document).on('click', '.edit-group', function() {
            const reviewId = $(this).data('id');
            toggleGroupEdit(reviewId);
        });

        $(document).on('click', '.save-group', function() {
            const reviewId = $(this).data('id');
            saveGroup(reviewId);
        });

        // Close editable fields on click outside
        $(document).on('click', function(e) {
            const editableFields = $('.editable-field:visible');
            if (editableFields.length && !$(e.target).closest('.editable-field, .edit-link, .edit-group').length) {
                editableFields.each(function() {
                    const fieldId = $(this).attr('id');
                    const reviewId = fieldId.split('_').pop();

                    if (fieldId.includes('link_edit')) {
                        toggleLinkEdit(reviewId);
                    } else if (fieldId.includes('group_edit')) {
                        handleGroupEditBlur(reviewId);
                    } else {
                        console.log('Unknown editable field:', fieldId);
                    }
                });
            }
        });

        // Initial load
        loadReviews();



    });
</script>