<?php
if (!defined('ABSPATH')) {
    exit;
}

class Personal_Reviews_Database
{
    private static $table_name;
    private static $version = '1.0';
    private static $version_option = 'personal_reviews_db_version';

    public static function init()
    {
        global $wpdb;
        self::$table_name = $wpdb->prefix . 'personal_reviews';
    }

    public static function create_tables()
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS " . self::$table_name . " (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            rating int(1) NOT NULL,
            review_text text NOT NULL,
            social_link varchar(255) DEFAULT NULL,
            user_cookie varchar(255),
            date_added datetime DEFAULT CURRENT_TIMESTAMP,
            status varchar(20) DEFAULT 'pending',
            group_id varchar(50) DEFAULT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        update_option(self::$version_option, self::$version);

        add_option('reviews_display_limit', 10);
    }

    public static function drop_tables()
    {
        global $wpdb;
        $wpdb->query("DROP TABLE IF EXISTS " . self::$table_name);
        delete_option(self::$version_option);
    }

    public static function maybe_upgrade()
    {
        if (get_option(self::$version_option) != self::$version) {
            self::create_tables();
        }
    }

    public static function get_reviews($args = array())
    {
        global $wpdb;

        $defaults = array(
            'status' => null,
            'orderby' => 'date_added',
            'order' => 'DESC',
            'limit' => -1,
            'offset' => 0
        );

        $args = wp_parse_args($args, $defaults);
        $where = array('1=1');

        if ($args['status']) {
            $where[] = $wpdb->prepare('status = %s', $args['status']);
        }

        $query = "SELECT * FROM " . self::$table_name . " WHERE " . implode(' AND ', $where);
        $query .= " ORDER BY {$args['orderby']} {$args['order']}";

        if ($args['limit'] > 0) {
            $query .= $wpdb->prepare(' LIMIT %d, %d', $args['offset'], $args['limit']);
        }

        // return $wpdb->get_results($query, ARRAY_A);

        $reviews = $wpdb->get_results($query, ARRAY_A);
        $settings = array(
            'displayMode' => get_option('reviews_display_mode', 'carousel'),
            'display_limit' => get_option('reviews_display_limit', 10)
        );

        return array(
            'reviews' => $reviews,
            'settings' => $settings
        );
    }

    public static function insert_review($data) {
        global $wpdb;
        error_log('Raw data received: ' . print_r($data, true));
    
        // Validate required fields
        if (empty($data['name'])) {
            return array(
                'success' => false,
                'error' => 'Name is required'
            );
        }
    
        $defaults = array(
            'status' => 'pending',
            'date_added' => current_time('mysql')
        );
    
        // Merge with defaults preserving original values
        $data = array_merge($defaults, $data);
        error_log('Merged data: ' . print_r($data, true));
    
        $insert = $wpdb->insert(
            self::$table_name,
            $data,
            array(
                '%s', // name
                '%d', // rating
                '%s', // review_text
                '%s', // social_link
                '%s', // user_cookie
                '%s', // date_added
                '%s', // status
                '%s'  // group_id
            )
        );
    
        if ($insert) {
            return array(
                'success' => true,
                'data' => $data,
                'insert_id' => $wpdb->insert_id
            );
        }
    
        error_log('Insert failed: ' . $wpdb->last_error);
        return array(
            'success' => false,
            'data' => $data,
            'error' => $wpdb->last_error
        );
    }

    public static function update_review($id, $data)
    {
        global $wpdb;

        return $wpdb->update(
            self::$table_name,
            $data,
            array('id' => $id),
            array(
                '%s', // name
                '%d', // rating
                '%s', // review_text
                '%s', // social_link
                '%s', // user_cookie
                '%s', // date_added
                '%s', // status
                '%s'  // group_id
            ),
            array('%d')
        );
    }

    public static function delete_review($id)
    {
        global $wpdb;
        return $wpdb->delete(
            self::$table_name,
            array('id' => $id),
            array('%d')
        );
    }

    public static function get_review_count($status = null)
    {
        global $wpdb;

        $query = "SELECT COUNT(*) FROM " . self::$table_name;
        if ($status) {
            $query .= $wpdb->prepare(" WHERE status = %s", $status);
        }

        return $wpdb->get_var($query);
    }
}

// Initialize database class
Personal_Reviews_Database::init();
