<?php
if (!defined('ABSPATH')) {
    exit;
}

class Personal_Reviews_Admin
{

    public function __construct()
    {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('wp_ajax_get_reviews_admin', array($this, 'get_reviews_admin'));
        add_action('wp_ajax_approve_review', array($this, 'approve_review'));
        add_action('wp_ajax_delete_review', array($this, 'delete_review'));
        add_action('wp_ajax_bulk_approve_reviews', array($this, 'bulk_approve_reviews'));
        add_action('wp_ajax_bulk_delete_reviews', array($this, 'bulk_delete_reviews'));
        add_action('wp_ajax_get_display_mode', array($this, 'get_display_mode'));
        add_action('wp_ajax_save_display_mode', array($this, 'save_display_mode'));
        add_action('wp_ajax_get_display_limit', array($this, 'get_display_limit'));
        add_action('wp_ajax_update_display_limit', array($this, 'update_display_limit'));
        add_action('wp_ajax_update_review_date', array($this, 'update_review_date'));
        add_action('wp_ajax_update_review_group', array($this, 'update_review_group'));
        add_action('wp_ajax_update_social_link', array($this, 'update_social_link'));
        add_action('wp_ajax_add_review_shortcode', array($this, 'add_review_shortcode'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_styles'));
    }



    public function enqueue_admin_styles($hook)
    {
        if ('toplevel_page_personal-reviews' !== $hook) {
            return;
        }

        wp_enqueue_style('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css');
        wp_enqueue_script('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr', array(), null, true);
        wp_enqueue_style(
            'personal-reviews-admin',
            plugins_url('assets/css/admin.css', dirname(__FILE__))
        );
    }

    public function add_review_shortcode()
    {
        $errors = [];

        if (!check_ajax_referer('reviews_admin_nonce', 'nonce', false)) {
            $errors['nonce'] = 'Невірний токен безпеки';
            wp_send_json_error(['errors' => $errors]);
        }

        if (!current_user_can('manage_options')) {
            $errors['permissions'] = 'Недостатньо прав';
            wp_send_json_error(['errors' => $errors]);
        }

        $name = sanitize_text_field($_POST['name']);
        if (empty($name)) {
            $errors['name'] = 'Назва шорткоду обов\'язкова';
            wp_send_json_error(['errors' => $errors]);
        }

        if (!isset($GLOBALS['shortcode_tags']['react_reviews'])) {
            $errors['base_shortcode'] = 'Базовий шорткод не знайдено';
            wp_send_json_error(['errors' => $errors]);
        }

        // Стан до змін
        $before_shortcodes = $this->get_active_shortcodes();
        $shortcodes = get_option('react_reviews_shortcodes', array());

        if (in_array($name, $shortcodes)) {
            $errors['duplicate'] = 'Такий шорткод вже існує';
            wp_send_json_error([
                'errors' => $errors,
                'shortcode' => $name,
                'existing' => $shortcodes,
                'active' => $before_shortcodes
            ]);
        }

        // Додавання нового шорткоду
        $shortcodes[] = $name;
        if (!update_option('react_reviews_shortcodes', $shortcodes)) {
            $errors['update'] = 'Помилка оновлення опцій';
            wp_send_json_error(['errors' => $errors]);
        }

        $base_callback = $GLOBALS['shortcode_tags']['react_reviews'];
        add_shortcode($name, $base_callback);

        if (!isset($GLOBALS['shortcode_tags'][$name])) {
            $errors['registration'] = 'Помилка реєстрації шорткоду';
            wp_send_json_error(['errors' => $errors]);
        }

        // Стан після змін
        $after_shortcodes = $this->get_active_shortcodes();

        wp_send_json_success([
            'message' => 'Групу оновлено',
            'shortcode' => $name,
            'before' => $before_shortcodes,
            'after' => $after_shortcodes,
            'saved_shortcodes' => $shortcodes,
            'active_shortcodes' => $after_shortcodes
        ]);
    }


    public function update_review_date()
    {
        check_ajax_referer('reviews_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Недостатньо прав'));
        }

        $review_id = absint($_POST['review_id']);
        $new_date = sanitize_text_field($_POST['date']);

        $result = Personal_Reviews_Database::update_review(
            $review_id,
            array('date_added' => $new_date)
        );

        if ($result) {
            wp_send_json_success(__('Дату оновлено'));
        } else {
            wp_send_json_error(__('Помилка при оновленні дати'));
        }
    }

    public function update_review_group()
    {
        check_ajax_referer('reviews_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Недостатньо прав');
        }

        $review_id = intval($_POST['review_id']);
        $group_id = sanitize_text_field($_POST['group_id']);

        global $wpdb;
        $result = $wpdb->update(
            $wpdb->prefix . 'personal_reviews',
            array('group_id' => $group_id),
            array('id' => $review_id),
            array('%s'),
            array('%d')
        );

        if ($result !== false) {
            wp_send_json_success('Групу оновлено');
        }

        wp_send_json_error('Помилка оновлення');
    }

    public function update_social_link()
    {
        check_ajax_referer('reviews_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Недостатньо прав'));
        }

        $review_id = absint($_POST['review_id']);
        $social_link = sanitize_url($_POST['social_link']);

        $result = Personal_Reviews_Database::update_review(
            $review_id,
            array('social_link' => $social_link)
        );

        if ($result) {
            wp_send_json_success(__('Посилання оновлено'));
        } else {
            wp_send_json_error(__('Помилка при оновленні посилання'));
        }
    }

    public function add_admin_menu()
    {
        add_menu_page(
            __('WP Відгуки', 'react-personal-reviews'),
            __('WP Відгуки', 'react-personal-reviews'),
            'manage_options',
            'personal-reviews',
            array($this, 'render_admin_page'),
            'dashicons-format-chat',
            30
        );
    }

    public function render_admin_page()
    {
        if (!current_user_can('manage_options')) {
            wp_die(__('У вас недостатньо прав для доступу до цієї сторінки.'));
        }

        include RPR_PLUGIN_DIR . 'templates/admin-panel.php';
    }

    private function get_active_shortcodes()
    {
        $shortcode_tags = $GLOBALS['shortcode_tags'];
        $active_shortcodes = array();

        foreach ($shortcode_tags as $tag => $callback) {
            $active_shortcodes[$tag] = array(
                'tag' => $tag,
                'callback' => is_array($callback) ? get_class($callback[0]) . '->' . $callback[1] : 'function'
            );
        }

        return $active_shortcodes;
    }

    public function get_reviews_admin()
    {
        check_ajax_referer('reviews_admin_nonce', 'nonce');

        $page = isset($_POST['page']) ? absint($_POST['page']) : 1;
        $per_page = 10;
        $offset = ($page - 1) * $per_page;

        $reviews = Personal_Reviews_Database::get_reviews(array(
            'status' => null,
            'limit' => $per_page,
            'offset' => $offset
        ));

        wp_send_json_success(array(
            'reviews' => $reviews['reviews'],
            'total' => Personal_Reviews_Database::get_review_count(),
            'per_page' => $per_page,
            'active_shortcodes' => $this->get_active_shortcodes()
        ));
    }

    public function approve_review()
    {
        check_ajax_referer('reviews_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Недостатньо прав'));
        }

        $review_id = absint($_POST['review_id']);

        $result = Personal_Reviews_Database::update_review(
            $review_id,
            array('status' => 'approved')
        );

        if ($result) {
            do_action('personal_reviews_review_approved', $review_id);
            wp_send_json_success(__('Відгук схвалено'));
        } else {
            wp_send_json_error(__('Помилка при схваленні відгуку'));
        }
    }

    public function delete_review()
    {
        check_ajax_referer('reviews_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Недостатньо прав'));
        }

        $review_id = absint($_POST['review_id']);

        $result = Personal_Reviews_Database::delete_review($review_id);

        if ($result) {
            do_action('personal_reviews_review_deleted', $review_id);
            wp_send_json_success(__('Відгук видалено'));
        } else {
            wp_send_json_error(__('Помилка при видаленні відгуку'));
        }
    }

    public function bulk_approve_reviews()
    {
        check_ajax_referer('reviews_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Недостатньо прав'));
        }

        $review_ids = array_map('absint', $_POST['review_ids']);
        $success = true;

        foreach ($review_ids as $review_id) {
            $result = Personal_Reviews_Database::update_review(
                $review_id,
                array('status' => 'approved')
            );
            if (!$result) {
                $success = false;
            }
        }

        if ($success) {
            wp_send_json_success(__('Відгуки схвалено'));
        } else {
            wp_send_json_error(__('Помилка при схваленні відгуків'));
        }
    }

    public function bulk_delete_reviews()
    {
        check_ajax_referer('reviews_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Недостатньо прав'));
        }

        $review_ids = array_map('absint', $_POST['review_ids']);
        $success = true;

        foreach ($review_ids as $review_id) {
            $result = Personal_Reviews_Database::delete_review($review_id);
            if (!$result) {
                $success = false;
            }
        }

        if ($success) {
            wp_send_json_success(__('Відгуки видалено'));
        } else {
            wp_send_json_error(__('Помилка при видаленні відгуків'));
        }
    }

    public function get_display_mode()
    {
        check_ajax_referer('display_mode_nonce', 'nonce');
        $mode = get_option('reviews_display_mode', 'carousel');
        wp_send_json_success(['mode' => $mode]);
    }

    public function save_display_mode()
    {
        check_ajax_referer('display_mode_nonce', 'nonce');
        $mode = sanitize_text_field($_POST['mode']);
        update_option('reviews_display_mode', $mode);
        wp_send_json_success();
    }

    public function get_display_limit()
    {
        check_ajax_referer('reviews_admin_nonce', 'nonce');
        $limit = get_option('reviews_display_limit', 10);
        wp_send_json_success(['limit' => $limit]);
    }

    public function update_display_limit()
    {
        check_ajax_referer('reviews_admin_nonce', 'nonce');
        $limit = intval($_POST['limit']);
        update_option('reviews_display_limit', $limit);
        wp_send_json_success();
    }
}
