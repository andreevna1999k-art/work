<?php
if (!defined('ABSPATH')) {
    exit;
}

class Personal_Reviews_Frontend
{
    public function __construct()
    {
        add_action('wp_ajax_submit_review', array($this, 'handle_review_submission'));
        add_action('wp_ajax_nopriv_submit_review', array($this, 'handle_review_submission'));
        add_action('wp_ajax_get_reviews', array($this, 'get_reviews'));
        add_action('wp_ajax_nopriv_get_reviews', array($this, 'get_reviews'));
    }

    public function handle_review_submission()
    {
        check_ajax_referer('react_reviews_nonce', 'nonce');

        $review_data = array(
            'name' => sanitize_text_field($_POST['reviewer_name']),
            'rating' => intval($_POST['review_rating']),
            'review_text' => sanitize_textarea_field($_POST['review_text']),
            'social_link' => esc_url_raw($_POST['social_link']),
            'user_cookie' => sanitize_text_field($_POST['user_cookie']),
            'group_id' => sanitize_text_field($_POST['group_id']),
            'date_added' => current_time('mysql'),
            'status' => 'pending'
        );

        global $wpdb;
        $table_name = $wpdb->prefix . 'personal_reviews';

        $result = $wpdb->insert(
            $table_name,
            $review_data,
            array('%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s')
        );

        // $result = Personal_Reviews_Database::insert_review($review_data);

        if ($result) {
            do_action('personal_reviews_new_review', $wpdb->insert_id);
            wp_send_json_success(__('Дякуємо!', 'react-personal-reviews'));
        } else {
            wp_send_json_error(__('Помилка.', 'react-personal-reviews'));
        }
    }

    //$status - це наприклад pending, approved, rejected
    public function get_reviews($status = null)
    {
        $result = Personal_Reviews_Database::get_reviews([
            'status' => $status,
            'orderby' => 'date_added',
            'order' => 'DESC'
        ]);

        // Додаємо форматування дат якщо потрібно
        foreach ($result['reviews'] as &$review) {
            $review['date_formatted'] = date_i18n(
                get_option('date_format'),
                strtotime($review['date_added'])
            );
        }

        wp_send_json_success($result);
    }

    public function render_review_form()
    {
        ob_start();
        include RPR_PLUGIN_DIR . 'templates/review-form.php';
        return ob_get_clean();
    }

    public function get_average_rating()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'personal_reviews';

        return $wpdb->get_var(
            $wpdb->prepare(
                "SELECT AVG(rating) FROM $table_name WHERE status = %s",
                'approved'
            )
        );
    }

    public function get_rating_counts()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'personal_reviews';

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT rating, COUNT(*) as count FROM $table_name WHERE status = %s GROUP BY rating ORDER BY rating DESC",
                'approved'
            ),
            ARRAY_A
        );

        $counts = array_fill(1, 5, 0);
        foreach ($results as $row) {
            $counts[$row['rating']] = intval($row['count']);
        }

        return $counts;
    }

    public function notify_admin_new_review($review_id)
    {
        $admin_email = get_option('admin_email');
        $subject = __('Новий відгук на сайті', 'react-personal-reviews');

        global $wpdb;
        $table_name = $wpdb->prefix . 'personal_reviews';
        $review = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $table_name WHERE id = %d",
                $review_id
            )
        );

        $message = sprintf(
            __('Новий відгук від %s потребує перевірки. Рейтинг: %d', 'react-personal-reviews'),
            $review->name,
            $review->rating
        );

        wp_mail($admin_email, $subject, $message);
    }
}
